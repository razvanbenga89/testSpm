//
//  Common.h
//  Common
//
//  Created by RazvanB on 08.04.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for Common.
FOUNDATION_EXPORT double CommonVersionNumber;

//! Project version string for Common.
FOUNDATION_EXPORT const unsigned char CommonVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Common/PublicHeader.h>


